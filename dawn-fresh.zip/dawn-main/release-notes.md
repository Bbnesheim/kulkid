Dawn 15.4.0 introduces support for nested cart lines, accessibility improvements, performance enhancements, and bug fixes.

### Added
- Added support for nested cart lines. Cart now properly displays nested  items( like product add-ons) with improved styling and accessibility labels
- Improved accessibility with added ARIA labels for product quantity inputs

### Changed
 - Improved performance by removing lazy loading of images above the fold in the Featured collection section
